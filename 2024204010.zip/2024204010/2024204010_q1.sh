#!/bin/bash
clear
grep "404" access.log
