Un Zip the folder
Navigate to the Directory where you un-Zipped 
open Terminal
Run 2024204010_q1.sh for question one output
Run 2024204010_q2.sh for Result of Question 2 
